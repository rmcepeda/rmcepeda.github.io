# Zachary-Sutherby.github.io

Dev github web server. 

### Work in progress, initial configuration likely to change.

Currently only contains a <a href="https://developers.arcgis.com/survey123/api-reference/rest/report/">Survey123 Feature Report REST API</a> sample. 

### Feature Report API Sample

URL: https://zachary-sutherby.github.io/?objectId=ObjectID&token=accessToken

Deploy to web server as needed, the sample will need to be updated with your own Feature Service REST URL's, survey item ID, and report template ID. The sample takes 2 URL parameters `objectId` and `token` both are used in the API calls that are sent. 
